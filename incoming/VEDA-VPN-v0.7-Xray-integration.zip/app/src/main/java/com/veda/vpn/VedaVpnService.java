package com.veda.vpn;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URI;
import java.net.URLDecoder;

public final class VedaVpnService extends VpnService {
    public static final String ACTION_CONNECT = "com.veda.vpn.CONNECT";
    public static final String ACTION_DISCONNECT = "com.veda.vpn.DISCONNECT";
    public static final String EXTRA_VLESS_LINK = "vless_link";
    private static final String TAG = "VEDA-XRAY";
    private static final int NOTIFICATION_ID = 8421;
    private ParcelFileDescriptor tun;
    private volatile boolean engineStarted;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_DISCONNECT.equals(intent.getAction())) {
            stopTunnel(); stopForeground(true); stopSelf(); return START_NOT_STICKY;
        }
        createChannel();
        startForeground(NOTIFICATION_ID, notification("VEDA VPN", "Starting VPN engine…"));
        String link = intent == null ? null : intent.getStringExtra(EXTRA_VLESS_LINK);
        if (link == null || !link.startsWith("vless://")) { fail("Only VLESS links are supported."); return START_NOT_STICKY; }
        try {
            stopTunnel();
            tun = new Builder().setSession("VEDA VPN").setMtu(1500)
                    .addAddress("10.77.0.2", 32).addRoute("0.0.0.0", 0)
                    .addDnsServer("1.1.1.1").addDnsServer("8.8.8.8").establish();
            if (tun == null) { fail("Android did not create VPN TUN."); return START_NOT_STICKY; }
            String config = buildConfig(link, tun.getFd());
            new Thread(() -> runEngine(config), "veda-xray-engine").start();
        } catch (Exception e) { Log.e(TAG, "VPN start failed", e); fail("VPN start failed: " + e.getMessage()); }
        return START_STICKY;
    }

    private String buildConfig(String link, int fd) throws Exception {
        URI u = URI.create(link);
        String uuid = u.getUserInfo(), host = u.getHost(); int port = u.getPort();
        if (uuid == null || host == null || port < 1) throw new IllegalArgumentException("Invalid VLESS URL");
        String q = u.getRawQuery() == null ? "" : u.getRawQuery();
        String security = param(q, "security", "none"), network = param(q, "type", "tcp");
        String sni = param(q, "sni", host), fp = param(q, "fp", "chrome");
        JSONObject stream = new JSONObject().put("network", network);
        if ("reality".equalsIgnoreCase(security)) stream.put("security", "reality")
                .put("realitySettings", new JSONObject().put("serverName", sni).put("fingerprint", fp)
                .put("publicKey", param(q, "pbk", "")).put("shortId", param(q, "sid", "")));
        else if ("tls".equalsIgnoreCase(security)) stream.put("security", "tls")
                .put("tlsSettings", new JSONObject().put("serverName", sni).put("fingerprint", fp));
        else stream.put("security", "none");
        if ("ws".equalsIgnoreCase(network)) stream.put("wsSettings", new JSONObject().put("path", param(q,"path","/"))
                .put("headers", new JSONObject().put("Host", param(q,"host",sni))));
        if ("grpc".equalsIgnoreCase(network)) stream.put("grpcSettings", new JSONObject().put("serviceName", param(q,"serviceName","")));
        if ("xhttp".equalsIgnoreCase(network)) stream.put("xhttpSettings", new JSONObject().put("path", param(q,"path","/")).put("host",param(q,"host",sni)));
        JSONObject user = new JSONObject().put("id", uuid).put("encryption", "none");
        String flow = param(q, "flow", ""); if (!flow.isEmpty()) user.put("flow", flow);
        JSONObject vnext = new JSONObject().put("address",host).put("port",port).put("users",new JSONArray().put(user));
        JSONObject proxy = new JSONObject().put("tag","proxy").put("protocol","vless")
                .put("settings",new JSONObject().put("vnext",new JSONArray().put(vnext))).put("streamSettings",stream);
        JSONObject direct = new JSONObject().put("tag","direct").put("protocol","freedom").put("settings",new JSONObject());
        JSONObject inbound = new JSONObject().put("tag","tun-in").put("protocol","tun")
                .put("settings",new JSONObject().put("name","veda-tun").put("MTU",1500));
        JSONObject rule = new JSONObject().put("type","field").put("inboundTag",new JSONArray().put("tun-in")).put("outboundTag","proxy");
        return new JSONObject().put("log",new JSONObject().put("loglevel","warning"))
                .put("inbounds",new JSONArray().put(inbound)).put("outbounds",new JSONArray().put(proxy).put(direct))
                .put("routing",new JSONObject().put("domainStrategy","AsIs").put("rules",new JSONArray().put(rule)))
                .put("env",new JSONObject().put("xray.tun.fd",String.valueOf(fd))).toString();
    }
    private String param(String q, String key, String fallback) throws Exception {
        for (String item:q.split("&")) { int i=item.indexOf('='); if(i>0 && URLDecoder.decode(item.substring(0,i),"UTF-8").equals(key)) return URLDecoder.decode(item.substring(i+1),"UTF-8"); }
        return fallback;
    }
    private void runEngine(String config) {
        try {
            Class<?> engine = null;
            for(String name:new String[]{"libXray.LibXray","com.xray.libxray.LibXray","io.github.wanliyunyan.libxray.LibXray"}) {
                try { engine=Class.forName(name); break; } catch(ClassNotFoundException ignored) {}
            }
            if(engine==null) throw new ClassNotFoundException("libXray Invoke class not found");
            String req = new JSONObject().put("apiVersion",3).put("method","runXray").put("payload",new JSONObject().put("xrayJson",config)).toString();
            String response = String.valueOf(engine.getMethod("invoke",String.class).invoke(null,req));
            JSONObject result = new JSONObject(response);
            if(!result.optBoolean("success",false)) throw new IllegalStateException(result.optString("error",response));
            engineStarted=true; updateNotification("VEDA VPN","Xray engine started");
        } catch(Throwable e) { Log.e(TAG,"libXray start failed",e); fail("Xray engine failed: "+e.getMessage()); }
    }
    private void stopTunnel() {
        if(engineStarted) {
            try {
                Class<?> engine=null;
                for(String name:new String[]{"libXray.LibXray","com.xray.libxray.LibXray","io.github.wanliyunyan.libxray.LibXray"}) {
                    try { engine=Class.forName(name); break; } catch(ClassNotFoundException ignored) {}
                }
                if(engine!=null) {
                    String req=new JSONObject().put("apiVersion",3).put("method","stopXray").put("payload",new JSONObject()).toString();
                    engine.getMethod("invoke",String.class).invoke(null,req);
                }
            } catch(Throwable e) { Log.w(TAG,"stop engine",e); }
            engineStarted=false;
        }
        if(tun!=null) { try { tun.close(); } catch(Exception ignored){} tun=null; }
    }
    private void fail(String message) { updateNotification("VEDA VPN",message); stopTunnel(); stopForeground(true); stopSelf(); }
    private void createChannel() {
        if(Build.VERSION.SDK_INT>=26) getSystemService(NotificationManager.class).createNotificationChannel(
                new NotificationChannel("veda_vpn_tunnel","VEDA VPN",NotificationManager.IMPORTANCE_LOW));
    }
    private Notification notification(String title,String message) {
        PendingIntent pi=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"veda_vpn_tunnel"):new Notification.Builder(this);
        return b.setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title).setContentText(message).setContentIntent(pi).setOngoing(true).build();
    }
    private void updateNotification(String title,String message) { NotificationManager nm=getSystemService(NotificationManager.class); if(nm!=null)nm.notify(NOTIFICATION_ID,notification(title,message)); }
    @Override public void onDestroy(){stopTunnel();super.onDestroy();}
}
