# VEDA VPN — Xray integration source

Adds Android `VpnService`, VPN permission flow, foreground service, VLESS share-link conversion, and the libXray Android AAR dependency:
`io.github.wanliyunyan:libxray:26.7.28` (published Android wrapper around XTLS/libXray/Xray-core).

**Not yet verified:** this ZIP has not been compiled or tested on an Android device in this environment. The AAR's generated Java package/method name may differ, and the TUN configuration schema must match the exact Xray-core build. Only VLESS links are currently handled. Do not treat the tunnel as working until GitHub Actions builds successfully and the APK is tested on a real device.
